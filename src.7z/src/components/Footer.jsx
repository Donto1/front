import React from "react";

const Footer = () => {
    return (
        <>
    <footer class="pt-4 my-md-5 pt-md-5 border-top">
        <div class="row">
            <div class="col-12 col-md">
                <small class="d-block mb-3 text-muted">&copy; 2017–2021</small>
            </div>
        </div>
    </footer>

        </>
    )
}
export default Footer