import React, {useEffect, useState} from 'react';
import './App.css';
import {Link, Route, Routes} from 'react-router-dom';
import Header from './components/Header';
import Index from './components/index';
import Login from './components/login';
import Registretion from './components/Registration';
import Orders from './components/Orders';
import Cart from './components/Cart';



function App() {
  const[isAuth, setIsAuth] = useState(false);
  const [loading, setLoading] = useState(false);
  const [products, setProducts] = useState([]);

  const [token, setToken] = useState('')

  return (
    <>
    <Routes>
      <Route
      path="/"
      element={ <Index isAuth={isAuth} setIsAuth={setIsAuth} setToken={setToken}
      token={token} products={products} setProducts={setProducts}/>}
      />
      <Route
        path="/login"
        element={<Login isAuth={isAuth} setIsAuth={setIsAuth} setToken={setToken}/>}
      />
      <Route
      path="/registration"
      element={<Registration isAuth={isAuth} setIsAuth={setIsAuth} setToken={setToken}/>}
      />
      {isAuth && (
        <>
        <Route path="/orders" element={<Orders isAuth={isAuth} setIsAuth={setIsAuth} setToken={setToken} token={token} products={products} />} />
        <Route
        path="/cart"
        element={
          <Cart isAuth={isAuth} setIsAuth={setIsAuth} setToken={setToken} token={token}/>
        }
        />
        </>
      )}
    </Routes>
    </>
  );
}


export default App;
